LOVE LUDO — ANDROID STUDIO PROJECT

Yeh Android app ka source project hai, APK file nahi.

APK banane ke liye:
1. Computer par Android Studio install karein.
2. Android Studio mein is folder ko Open karein.
3. Firebase project banayein aur web config values app/src/main/assets/index.html mein placeholders ki jagah paste karein.
4. Firebase Authentication mein Anonymous sign-in enable karein.
5. Firebase Realtime Database banayein aur testing rules ko SETUP.txt ke mutabiq configure karein.
6. Android Studio mein Build > Build Bundle(s) / APK(s) > Build APK(s) select karein.

Note:
- Online multiplayer tab tak kaam nahi karega jab tak Firebase config aur database setup na ho.
- Project ko APK mein compile karne ke liye Android SDK/Android Studio chahiye.
- Firebase ke test database rules production ke liye secure nahi; public launch se pehle membership validation zaroori hai.
